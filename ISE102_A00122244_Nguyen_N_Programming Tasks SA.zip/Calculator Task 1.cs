﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simple_calculator_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Prompt user to enter the first number
            Console.Write("Enter the first number: ");
            // Converts the input into a double type and reads the user's input from the console, thus converting it from string to double to allow arithmetic operations.
            double num1 = Convert.ToDouble(Console.ReadLine());

            // Prompt user to enter the second number
            Console.Write("Enter the second number: ");
            // Convert the input to a double type
            double num2 = Convert.ToDouble(Console.ReadLine());

            // Perform addition and display the result
            Console.WriteLine($"{num1} + {num2} = {num1 + num2}");

            // Perform subtraction and display the result
            Console.WriteLine($"{num1} - {num2} = {num1 - num2}");

            // Perform multiplication and display the result
            Console.WriteLine($"{num1} * {num2} = {num1 * num2}");

            // Perform division
            // Check if the second number is not zero to avoid division by zero
            if (num2 != 0)
            {
                Console.WriteLine($"{num1} / {num2} = {num1 / num2}");
            }
            else
            {
                Console.WriteLine("Division by zero is not allowed.");
            }

            // Wait for the user to press a key before closing the console window
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}
