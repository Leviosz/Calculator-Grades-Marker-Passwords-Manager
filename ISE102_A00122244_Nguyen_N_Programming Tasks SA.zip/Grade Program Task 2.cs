﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple_Online_Grading_Program_Task_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Prompt the user to enter a score
            Console.Write("Enter the score (0-100): ");
            // Read the score from the console and convert it from string to an integer, as scores are numerical.
            int score = Convert.ToInt32(Console.ReadLine());

            // Variable to hold the grade as the acutal grade is assigned based on the score through decision-making statements.
            string grade;

            // Decision rule for assigning grades based on the score
            if (score >= 85 && score <= 100)
            {
                grade = "High Distinction";
            }
            else if (score >= 75 && score <= 84)
            {
                grade = "Distinction";
            }
            else if (score >= 65 && score <= 74)
            {
                grade = "Credit";
            }
            else if (score >= 55 && score <= 64)
            {
                grade = "Pass";
            }
            else if (score >= 0 && score <= 54)
            {
                grade = "Fail";
            }
            else
            {
                // Handle invalid scores (less than 0 or greater than 100)
                grade = "Invalid";
            }

            // Output the grade to the console. The '$' before the string allows us to insert the variable 'grade' diretly into the string.
            Console.WriteLine($"Grade: {grade}");

            // Wait for the user to press a key before closing the console window
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}
