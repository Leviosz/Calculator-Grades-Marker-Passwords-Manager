﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
//In C#, the Regex class is part of the System.Text.RegularExpressions namespace, which is why we include it using a using directive at the beginning of the file.
//This directive tells the compiler that we intend to use classes from this namespace in our program, making all its classes and methods available without needing to specify the full namespace path each time.
//E.g When we have System.Text.RegularExpressions at the top, we don't have to use System.Text.RegularExpressions.Regex.IsMatch(...) every time we wanted to use the IsMatch method of the Regex class, which would make the code more verbose and harder to read.
//In my program, Regex.IsMatch(input, pattern) is used to check if the input string matches the specified pattern. The patterns used help determine if the string is alphanumeric and contains at least one special character, which are requirements for the password input.
using System.Threading.Tasks;

namespace Passwords_authenicator_task_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string correctPassword = "4Torren$"; // Correct password is set to "4Torren$"
            int attempts = 0;

            while (attempts < 3)
            {
                Console.Write("Enter password: ");
                string userInput = Console.ReadLine();

                // Checks if the input contains a mix of letters and numbers and at least one special character
                if (IsAlphanumericAndHasSpecialChar(userInput))
                {
                    if (userInput == correctPassword)
                    {
                        Console.WriteLine("Welcome, member!");
                        return; // Exit the program upon successful password entry
                    }
                    else
                    {
                        Console.WriteLine("Incorrect password.");
                    }
                }
                else
                {
                    Console.WriteLine("Password must contain letters, numbers, and at least one special character.");
                }

                attempts++; // Increment the attempt counter
            }

            Console.WriteLine("Goodbye."); // Say goodbye and end the program if the correct password isn't entered within 3 attempts
        }

        static bool IsAlphanumericAndHasSpecialChar(string input)
        {
            // This pattern checks for the presence of at least one letter, at least one digit, and at least one special character. We also use
            // positive lookaheads (?=) to assert that the string contains the necessary character types without consuming characters or moving the regex engine's position within the string,
            // allowing it to check for multiple independent conditions within the same pattern.
            bool isValid = Regex.IsMatch(input, @"^(?=.*[a-zA-Z])(?=.*\d)(?=.*[^a-zA-Z\d]).+$");

            return isValid;
        }
    }
}
